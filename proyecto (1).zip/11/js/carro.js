import { prolist } from "./carrito.js";

y=prolist


console.log(y)


carrito.forEach((x) =>{
    console.log(x)
})
addEventListener('click', ()=>{
    carrito.forEach((x) =>{
        console.log(x)
    })
})